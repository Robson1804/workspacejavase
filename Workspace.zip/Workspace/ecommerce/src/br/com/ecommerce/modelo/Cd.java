package br.com.ecommerce.modelo;

public class Cd extends Produto {
	private String artista;
	private String gravadora;
	private String duracao;
	
	
	
	public Cd(int i, String desc, float vc, float vv, int q, String t, String artista, String gravadora, String duracao) {
		super(i, desc, vc, vv, q, t);
		this.artista = artista;
		this.gravadora = gravadora;
		this.duracao = duracao;
	}
	
		
	public Cd() {
		super();
	}
	
	public void setAll(int i, String desc, float vc, float vv, int q, String t, String artista, String gravadora, String duracao) {
		setAll(i, desc, vc, vv, q, t);
		this.artista = artista;
		this.gravadora = gravadora;
		this.duracao = duracao;
	}
	
	public String getAll () {
		return
		"Artista:" + artista + "\n" +
		"Gravadora:" + gravadora + "\n" +
		"Dura��o:" + duracao + "\n" +
		super.getAll(); // O "super." significa que estou usando o "getAll" da classe pai.
	}



	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	public String getGravadora() {
		return gravadora;
	}
	public void setGravadora(String gravadora) {
		this.gravadora = gravadora;
	}
	public String getDuracao() {
		return duracao;
	}
	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}

}
