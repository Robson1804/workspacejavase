package br.com.ecommerce.modelo;

public class Produto {
	private int id;
	private String descricao;
	private float valorCompra;
	private float valorVenda;
	private int qtde;
	private String tipo;
	
	/*Criando o CONSTRUTOR (envolvido na inst�ncia do objeto)
	 * O construtor pode receber valores atrav�s dos atributos para instanciar j� com estes valores
	 * DTO determina que toda classe beans deve conter no m�nimo 2 CONSTRUTORES (um vazio e um cheio)
	 */
	//CONSTRUTOR VAZIO
	public Produto() {
	}
	
	//CONSTRUTOR CHEIO
	public Produto(int i, String desc, float vc, float vv, int q, String t) {
		id = i;
		descricao = desc;
		valorCompra = vc;
		valorVenda = vv;
		qtde = q;
		tipo = t;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public float getValorCompra() {
		return valorCompra;
	}
	public void setValorCompra(float valorCompra) {
		this.valorCompra = valorCompra;
	}
	public float getValorVenda() {
		return valorVenda;
	}
	public void setValorVenda(float valorVenda) {
		this.valorVenda = valorVenda;
	}
	public int getQtde() {
		return qtde;
	}
	public void setQtde(int qtde) {
		this.qtde = qtde;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public float getTotalVenda() {
		return valorVenda * qtde;
	}
	public float getPromocao() {
		return valorVenda - (float) 0.9;
	}
	public String getEstoque() {
		if (qtde<5) {
			return "Baixo";
		}else if (qtde>10) {
			return "Alto";
		}else {
			return "Medio";
		}
	}
	public void setentrarEstoque(int pEntrarEstoque) {
		this.qtde = qtde + pEntrarEstoque;
	}
	public int getentrarEstoque() {
		return qtde;
	}
	public void setsairEstoque(int pSairEstoque) {
		this.qtde = qtde - pSairEstoque;
	}
	public int getsairEstoque() {
		return qtde;
	}
	public float cederDesconto(float porcentagem) {
        return valorVenda - valorVenda * (porcentagem/100);
    }
	public void ajustarValores(float porcentagem) {
        valorCompra = valorCompra + valorCompra * (porcentagem/100);
        valorVenda = valorVenda + valorVenda * (porcentagem/100);
    }
	public void setAll (int id, String descricao, float valorCompra, float valorVenda, int qtde, String tipo) {
		this.id=id;
		this.descricao=descricao;
		this.valorCompra=valorCompra;
		this.valorVenda=valorVenda;
		this.qtde=qtde;
		this.tipo=tipo;
	}
	public String getAll() {
		return id + "\n" + descricao + "\n" + valorCompra + "\n" + valorVenda + "\n" + qtde + "\n" + tipo;
	}

}
