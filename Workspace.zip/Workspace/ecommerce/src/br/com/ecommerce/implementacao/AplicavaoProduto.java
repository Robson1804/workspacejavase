package br.com.ecommerce.implementacao;

import br.com.ecommerce.modelo.Cd;
import br.com.ecommerce.modelo.Livro;
import br.com.ecommerce.tela.Magica;

public class AplicavaoProduto {

	public static void main(String[] args) {

		char opcao = Magica.s("DIGITE <L> OU <C>").charAt(0);
		if (opcao =='L') {
			Livro obj1 = new Livro(
					Magica.i("ID"),
					Magica.s("DESCRI��O"),
					Magica.f("COMPRA"),
					Magica.f("VENDA"),
					Magica.i("QTDE"),
					Magica.s("TIPO"),
					Magica.s("ISBN"),
					Magica.s("AUTOR"),
					Magica.s("EDITORA")
					);
			System.out.println(obj1.getAll());
		}else if (opcao =='C') {
			Cd obj2 = new Cd(
					Magica.i("ID"),
					Magica.s("DESCRI��O"),
					Magica.f("COMPRA"),
					Magica.f("VENDA"),
					Magica.i("QTDE"),
					Magica.s("TIPO"),
					Magica.s("ISBN"),
					Magica.s("AUTOR"),
					Magica.s("EDITORA")
					);
			System.out.println(obj2.getAll());
				
			}

	}

}
