package br.com.ecommerce.implementacao;

import br.com.ecommerce.modelo.Cd;
import br.com.ecommerce.modelo.Livro;
import br.com.ecommerce.modelo.Produto;
import br.com.ecommerce.tela.Magica;

public class AplicavaoProduto2 {

	public static void main(String[] args) {
		Produto obj3 = new Produto();
		
		char opcao = Magica.s("DIGITE <L> OU <C>").charAt(0);
		if (opcao =='L') {
			obj3 = new Livro(
					Magica.i("ID"),
					Magica.s("DESCRI��O"),
					Magica.f("COMPRA"),
					Magica.f("VENDA"),
					Magica.i("QTDE"),
					Magica.s("TIPO"),
					Magica.s("ISBN"),
					Magica.s("AUTOR"),
					Magica.s("EDITORA")
					);
		}else if (opcao =='C') {
			obj3 = new Cd(
					Magica.i("ID"),
					Magica.s("DESCRI��O"),
					Magica.f("COMPRA"),
					Magica.f("VENDA"),
					Magica.i("QTDE"),
					Magica.s("TIPO"),
					Magica.s("ISBN"),
					Magica.s("AUTOR"),
					Magica.s("EDITORA")
					);
			
				
			} else {
				System.out.println("Op��o Inv�lida");
			}
		System.out.println(obj3.getAll());

	}
	

}
