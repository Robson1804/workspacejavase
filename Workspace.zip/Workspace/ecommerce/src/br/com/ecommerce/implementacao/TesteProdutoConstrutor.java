package br.com.ecommerce.implementacao;

import javax.swing.JOptionPane;

import br.com.ecommerce.modelo.Produto;

public class TesteProdutoConstrutor {

	public static void main(String[] args) {
		Produto obj2 = new Produto(
				Integer.parseInt(JOptionPane.showInputDialog("ID")),
				JOptionPane.showInputDialog("DESCRICAO").toUpperCase(),
				Float.parseFloat(JOptionPane.showInputDialog("Valor Compra")),
				Float.parseFloat(JOptionPane.showInputDialog("Valor Venda")),
				Integer.parseInt(JOptionPane.showInputDialog("QTDE")),
				JOptionPane.showInputDialog("TIPO")
				);
		
		System.out.println(obj2.getAll());

	}

}
