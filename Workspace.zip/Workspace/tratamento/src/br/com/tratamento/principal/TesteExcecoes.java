package br.com.tratamento.principal;

public class TesteExcecoes {

	public static void main(String[] args) {
		//Teste sobre retorno de mensagens de "Execption"
		try {
			int numero = Integer.parseInt("1");
			System.out.println(numero);
			String palavra = "OI!";
			
			System.out.println(palavra.length());
			
			int nums[] = new int[2];
			nums[0] = 521;
			nums[1] = 350;
			nums[2]	= 150;
			
		}catch (NumberFormatException e) { //Erro verificado com o "printStackTrace()
			System.out.println("N�mero Inv�lido");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Erro de Vetor");
		}catch (Exception e) {
			System.out.println("Erro Desconhecido");
			//e.printStackTrace();
		}
	}

}
