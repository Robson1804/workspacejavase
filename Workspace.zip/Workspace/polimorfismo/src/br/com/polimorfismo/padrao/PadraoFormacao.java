package br.com.polimorfismo.padrao;

public interface PadraoFormacao {
	String exibirDetalhes();
	void calculaMensalidade(double fator);

}
