package br.com.polimorfismo.implementacao;

import br.com.polimorfismo.beans.Bacharelado;
import br.com.polimorfismo.beans.Formacao;
import br.com.polimorfismo.beans.Medio;
import br.com.polimorfismo.beans.Tecnologo;
import br.com.polimorfismo.tela.Magica;

public class TesteFormacao {

	public static void main(String[] args) {
		Formacao obj1 = new Formacao();
			char resp = Magica.s("Digite a Forma��o: <M> para M�dio / <B> para Bacharelado / <T> para Tecnologo").charAt(0);
			String descricao = Magica.s("DESCRI�AO");
			int periodo = Magica.i("DIGITE O PER�ODO: <N> PARA NOITE / <D> PARA DIA");
			
			if (resp == 'M') {
				obj1 = new Medio(
				descricao,
				periodo,
				0,
				0,
				Magica.s("Tipo")
				);
			}
			if (resp == 'B') {
				obj1 = new Bacharelado( );
				
			}
			if (resp == 'T') {
				obj1 = new Tecnologo();
				
			}

	}

}
