package br.com.polimorfismo.beans;

public class Medio extends Formacao {
	private String tipo;

	public Medio(String desc, int p, double m, int d, String tipo) {
		super(desc, p, m, d);
		this.tipo = tipo;
	}

	public Medio() {
		super();
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public void calculaMensalidade(double fator) {
		super.setMensalidade(super.getDuracao() * fator * 500);
	}
	
	public void setAll (String desc, int p, double m, int d, String tipo) {
		setAll(desc, p, m, d);
		this.tipo = tipo;
	}
	
	public String getAll() {
		return
		"TIPO: " + tipo + "\n" +
		super.getAll();
	}


}
