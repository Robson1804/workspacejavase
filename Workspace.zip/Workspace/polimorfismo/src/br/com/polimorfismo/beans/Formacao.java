package br.com.polimorfismo.beans;

public class Formacao {
	private String descricao;
	private int periodo;
	private double mensalidade;
	private int duracao;
	
	public Formacao(String desc, int p , double m , int d) {
		super();
		this.descricao = desc;
		this.periodo = p;
		this.mensalidade = m;
		this.duracao = d;
	}

	public Formacao() {
		super();
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getPeriodo() {
		return periodo;
	}

	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}

	public double getMensalidade() {
		return mensalidade;
	}

	public void setMensalidade(double mensalidade) {
		this.mensalidade = mensalidade;
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	
	public double exibirMedia(double ps1, double ps2) {
		return (ps1 + ps2) / 2; 
	}
	
	public double exibirMedia(double ps1, double ps2, double nac1, double nac2) {
		return (ps1*0.4 + ps2*0.4 + nac1*0.1 + nac2*0.1) / 4; 
	}
	
	public double exibirMedia(double ps1, double ps2, double nac1, double nac2, double am1, double am2) {
		return (ps1*0.25 + ps2*0.25 + nac1*0.1 + nac2*0.1 + am1*.15 + am2*0.15) / 6; 
	}
	
	public void definirDuracao() {
		if (this instanceof Medio) { //Traduzindo o "this instanceof" = se o objeto desta classe for instanciado pela classe "Medio"
			duracao=36;
		}else if (this instanceof Tecnologo) {
			duracao=24;
		}else if (this instanceof Bacharelado) {
			if (descricao.indexOf("ENGENHARIA")==-1) {
				duracao=48;
			}else {
				duracao=60;
			}
		}
	}
	
	public void calculaMensalidade(double fator) {}
	
	public void setAll(String desc, int p , double m , int d) {
		this.descricao = desc;
		this.periodo = p;
		this.mensalidade = m;
		this.duracao = d;
	}
	
	public String getAll() {
		return 
		"DESCRI��O: " + descricao + "\n" +
		"PER�ODO: " + periodo + "\n" +
		"MENSALIDADE: " + mensalidade + "\n" +
		"DURA��O: " + duracao + "\n";
	}


}
