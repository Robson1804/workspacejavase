package br.com.polimorfismo.beans;

public class Tecnologo extends Formacao {
	private boolean planoEstendido;

	public Tecnologo(String desc, int p, double m, int d, boolean planoEstendido) {
		super(desc, p, m, d);
		this.planoEstendido = planoEstendido;
	}

	
	public Tecnologo() {
		super();
	}



	public boolean isPlanoEstendido() {
		return planoEstendido;
	}

	public void setPlanoEstendido(boolean planoEstendido) {
		this.planoEstendido = planoEstendido;
	}
	
	public void calculaMensalidade(double fator) {
		super.setMensalidade(super.getDuracao() * fator * 600);
	}
	
	public void setAll(String desc, int p, double m, int d, boolean planoEstendido) {
		setAll(desc, p, m, d);
		this.planoEstendido = planoEstendido;
	}
	
	public String getAll() {
		return
		"O PLANO � ESTENDIDO?:" + planoEstendido + "\n" +
		super.getAll();
	}

}
