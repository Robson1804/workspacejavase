package br.com.polimorfismo.beans;

import br.com.polimorfismo.padrao.PadraoFormacao;

public class Especializacao extends Formacao implements PadraoFormacao {

	@Override
	public String exibirDetalhes() {
		// TODO Auto-generated method stub
		return null;
	}



}
