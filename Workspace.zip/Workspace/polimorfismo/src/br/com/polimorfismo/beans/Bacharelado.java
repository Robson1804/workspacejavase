package br.com.polimorfismo.beans;

import br.com.polimorfismo.padrao.PadraoFormacao;

public class Bacharelado extends Formacao implements PadraoFormacao{
	private String projetoConclusao;
	private int cargaHorarioEstagio;
	
	public Bacharelado(String desc, int p, double m, int d, String projetoConclusao, int cargaHorarioEstagio) {
		super(desc, p, m, d);
		this.projetoConclusao = projetoConclusao;
		this.cargaHorarioEstagio = cargaHorarioEstagio;
	}

	public Bacharelado() {
		super();
	}


	public String getProjetoConclusao() {
		return projetoConclusao;
	}

	public void setProjetoConclusao(String projetoConclusao) {
		this.projetoConclusao = projetoConclusao;
	}

	public int getCargaHorarioEstagio() {
		return cargaHorarioEstagio;
	}

	public void setCargaHorarioEstagio(int cargaHorarioEstagio) {
		this.cargaHorarioEstagio = cargaHorarioEstagio;
	}
	
	public void calculaMensalidade(double fator) {
		super.setMensalidade((super.getDuracao() * fator * 600) + (cargaHorarioEstagio * 12)) ;
	}
	
	public void setAll(String desc, int p, double m, int d, String projetoConclusao, int cargaHorarioEstagio) {
		setAll(desc, p, m, d);
		this.projetoConclusao = projetoConclusao;
		this.cargaHorarioEstagio = cargaHorarioEstagio;
	}
	
	public String getAll() {
		return
		"PROJETO CONCLUSAO    : " + projetoConclusao + "\n" +
		"CARGA HORARIO EST�GIO: " + cargaHorarioEstagio + "\n" +
		super.getAll();
	}

	@Override
	public String exibirDetalhes() {
		// TODO Auto-generated method stub
		return null;
	}

}
