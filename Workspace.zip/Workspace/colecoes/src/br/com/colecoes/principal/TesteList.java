package br.com.colecoes.principal;

import java.util.ArrayList;
import java.util.Collections;

public class TesteList {

	public static void main(String[] args) {
		// Collection framework => COM VETORES
		ArrayList<String> lista = new ArrayList<String>();
		//do {
		//	lista.add(JOptionPane.showInputDialog("Digite o seu cargo:").toUpperCase());
		//}while (JOptionPane.showConfirmDialog
		//(null, "Continuar?", "Titulo", JOptionPane.YES_NO_OPTION)==0);
		//System.out.println(lista);
		lista.add("DBA");
		lista.add("DEV");
		lista.add("ESTAGIARIO");
		lista.add("ANALSITA");
		lista.add("DBA");
		System.out.println(lista.get(2));
		System.out.println(lista.remove(2));
		
		System.out.println("Sem Ordenar:" + lista);
		Collections.sort(lista);
		System.out.println("Ordenado:" + lista);
		
		//FOR CONVENCIONAL
		for (int cont=0;cont<lista.size();cont++) {
			System.out.println("Cargo: " + lista.get(cont));
			System.out.println("=====================");
		}
		
		//FOR EACH
		for (String elemento : lista) {
			System.out.println("Cargo: " + elemento);
			System.out.println("=====================");
		}
	}

}
