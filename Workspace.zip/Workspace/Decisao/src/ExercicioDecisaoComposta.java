import javax.swing.JOptionPane;

public class ExercicioDecisaoComposta {

	public static void main(String[] args) {
		String nome = JOptionPane.showInputDialog("Digite o seu nome");
		int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a sua idade"));
		if (idade >=18 && idade<=70) {
			System.out.println(nome + ", voc� � obrigado a votar");
		}else if (idade==16 || idade==17 || idade>=70) {
			System.out.println(nome + ", o seu voto � facultativo");
		}else if (idade <16) {
			System.out.println(nome + ", voc� n�o pode votar");
		}
	}

}
