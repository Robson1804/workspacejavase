import javax.swing.JOptionPane;

public class ContaHotel {

	public static void main(String[] args) {
		/* diaria - 80.00
		 * Taxas: 
		 * 5.50 se diarias > 15
		 * 6.00 se diarias = 15
		 * 8.00 se diarias < 15
		 */
		String hospede = JOptionPane.showInputDialog("Digite o nome do h�spede").toUpperCase();
		short diarias = Short.parseShort(JOptionPane.showInputDialog("Digite a qtde de di�rias"));
		float valDiaria = 80;
		if (diarias > 15) {
			valDiaria = (valDiaria + (float) 5.50);
		}else if (diarias == 15) {
			valDiaria = (valDiaria + (float) 6.00);
		}else
			valDiaria = (valDiaria + (float) 8.00);
		System.out.println("Nome do H�spede: " + hospede);
		System.out.println("Valor Total: " + valDiaria*diarias);
		
	}

}
