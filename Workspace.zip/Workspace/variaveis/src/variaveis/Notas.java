package variaveis;

import java.util.Scanner;

public class Notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Digite nome do aluno: ");
		String nome = teclado.next();
		System.out.println("Digite a nota1 do aluno: ");
		double nota1 = teclado.nextDouble();
		System.out.println("Digite a nota2 do aluno: ");
		double nota2 = teclado.nextDouble();
		System.out.println("Aluno: " + nome);
		double media = (nota1 + nota2) / 2;
		System.out.println("media: " + media);
		//%f - numeros reais
		//%d - numeros inteiros
		//%s - strings
		System.out.printf("Aluno %s sua m�dia � %.2f \n", nome, media);
		teclado.close();
	}

}
