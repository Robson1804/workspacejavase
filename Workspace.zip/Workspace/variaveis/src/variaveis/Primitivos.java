package variaveis;

public class Primitivos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Hierarquia (do meno para o maior)
		 * boolean = l�gico (true/false)
		 * char = representa 1 caracter. Identifiado por ''
		 * 
		 * Para inteiros:
		 * byte = -127/+128
		 * short = -32000.../+32000...
		 * int = -1 milh�o/+1 milh�o (default java)
		 * long = 
		 * 
		 * Para reais:
		 * float = Menos preci�o
		 * double = Dobro de precis�o do float (default java)
		 */
		//Cast - � o processo de convers�o entre dados primitivos (maior => menor)
		float valor = 1000;
		float desconto = valor * (float) 0.1;
		System.out.println("Valor do desconto: " + desconto);
	}

}
