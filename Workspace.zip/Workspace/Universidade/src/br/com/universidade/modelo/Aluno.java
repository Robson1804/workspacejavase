package br.com.universidade.modelo;

/*
 * Designer Pattern (Padr�es de desenvolvimento)
 * Um dos Pattern�s � o DTO (Data Transfer Object), cont�m pr�ticas para montar uma classe
 * modelo/bean/java bean/to/dto (Todos com o mesmo prop�sito)
 * Entre as pr�ticas do DTO, est�o:
 * - Os atributos devem ser privados
 * - Todo atributo deve possuir um Getter e um Setter
 */
public class Aluno {

		private int rm;
		private String nome;
		private String email;
		/*Cria��o do m�todo
		 * <modificado> <retorno> <nomeDoMetodo> (<tipoParametro1>, <nomeParametro1>, ...)
		 */
		public void preencherNome (String pNome) {
			nome = pNome.toUpperCase();
		}
		public void preencherRm (int pRm) {
			rm = pRm;
		}
		public void preencherEmail (String pEmail) {
			email = pEmail.toLowerCase();
		} 
		public String retornarNome() {
			return nome;
		}
		public String retornarEmail() {
			return email;
		}
		public int retornarRm() {
			return rm;
		}
	}

