package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.Aluno;

public class TesteAluno {

	public static void main(String[] args) {
		//Criando o ojbeto
		//Aluno objeto;
		
		//Instanciando o objeto
		Aluno objeto = new Aluno();
		objeto.preencherNome(JOptionPane.showInputDialog("Digito o nome do aluno"));
		objeto.preencherRm(Integer.parseInt(JOptionPane.showInputDialog("Digito o RM")));
		objeto.preencherEmail(JOptionPane.showInputDialog("Digito o email"));
		
		
		System.out.println("Nome do aluno: " + objeto.retornarNome());
		System.out.println("RM do Aluno: " + objeto.retornarRm());
		System.out.println("Email do Aluno: " + objeto.retornarEmail());

	}

}
