package br.com.universidadereferencia.principal;

import br.com.universidadereferencia.beans.Aluno;
import br.com.universidadereferencia.beans.Curso;
import br.com.universidadereferencia.beans.Endereco;
import br.com.universidadereferencia.beans.Turma;
import br.com.universidadereferencia.tela.Magica;

public class TesteTurma {

	public static void main(String[] args) {
		Turma obj1 = new Turma();
		Curso obj2 = new Curso();
		Aluno obj3 = new Aluno();
		Endereco obj4 = new Endereco();
		
		obj1.setSigla(Magica.s("Digite a Silga"));
		obj1.setPeriodo(Magica.s("Digite o per�odo"));
		obj1.setCurso(obj2);
		obj1.setAluno(obj3);
		obj2.setNome(Magica.s("Digite o curso"));
		obj3.setNome(Magica.s("Digite o nome do aluno"));
		
		System.out.println(obj1.getAll());
		System.out.println(obj4.getAll());
		
				
	}

}
