package br.com.projetofinal.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetofinal.beans.Usuario;
import br.com.projetofinal.dao.UsuarioDao;



@RestController
public class UsuarioController {
	
	@Autowired
	private UsuarioDao dao;
	
	@PostMapping("/login")
	public ResponseEntity<Usuario> logar(@RequestBody Usuario user) {
		Usuario resposta = dao.findByEmailAndSenha(user.getEmail(), user.getSenha());
		if (resposta==null) {
			return ResponseEntity.status(404).build();
		}
		return ResponseEntity.ok(resposta);
	}
	
	@GetMapping("/usuario/{codigo}")
	public ResponseEntity<Usuario> getUsuario(@PathVariable int codigo) { //PathVariable é usado para quando queremos indicar que caminho "URL" especifico
		Usuario resposta = dao.findById(codigo).orElse(null);
		if (resposta==null) {
			return ResponseEntity.status(404).build();
		}
		return ResponseEntity.ok(resposta);
	}
	
	
	@GetMapping("/usuarios") //Direciona a saida no formato WEB "localhost:8080/usuarios"
	public ResponseEntity <ArrayList<Usuario>> getAll() {
		ArrayList<Usuario> lista = (ArrayList<Usuario>) dao.findAll();
		if (lista.size()==0) {
			return ResponseEntity.status(404).build();
		}
		return ResponseEntity.ok(lista);
	}

}
