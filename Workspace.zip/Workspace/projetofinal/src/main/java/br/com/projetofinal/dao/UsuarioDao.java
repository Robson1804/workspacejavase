package br.com.projetofinal.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.projetofinal.beans.Usuario;

/* DAO => DATA ACCESS OBJECT - Design Patter que sugere a criação do CRUD desta classe
 * CRUD => CREATE, READ, UPDATE, DELETE
 * 
 */
public interface UsuarioDao extends CrudRepository<Usuario,Integer>{
	
	Usuario findByEmailAndSenha(String email, String senha);
	

}
