import javax.swing.JOptionPane;

public class ExemploWhile {

	public static void main(String[] args) {
		String email = JOptionPane.showInputDialog("Digite um email:").toUpperCase();
		while (email.indexOf("@")==-1) {
			email = JOptionPane.showInputDialog("Digite um email v�lido:").toUpperCase();
		}
		System.out.println(email.substring(0,email.indexOf("@")));
	}

}
