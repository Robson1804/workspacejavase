import javax.swing.JOptionPane;

public class DesafioDo {

	public static void main(String[] args) {
		char resp=0;
		int num1=0;
		int num2=0;
		do {
			num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro n�mero:"));
			num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo n�mero:"));
			System.out.println("Soma: " + (num1+num2));
			resp = JOptionPane.showInputDialog("Digite <S> para continuar").toUpperCase().charAt(0);
		}while(resp =='S');
	}
}
