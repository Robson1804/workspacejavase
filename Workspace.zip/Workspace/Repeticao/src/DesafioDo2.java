import javax.swing.JOptionPane;

public class DesafioDo2 {
	//Game de advinha��o
	// Jogador 1 vai digitar um n�mero inteiro
	// Jogador 2 tem que descobrir, enquanto ele n�o descobrir
	// pede novamente um n�mero e d� uma dica se ele est� arriscando um n�mero
	// maior ou menor que o n�mero que ele tem que advinhar.
	// Plus: exibir no final quantas tentativas ele usou.
	
	public static void main(String[] args) {
		//char resp=0;
		//int num1=0;
		int chute=0;
		int contador=0;
		int num = Integer.parseInt(JOptionPane.showInputDialog("Jogador 1 - Digite um n�mero:"));
		//Usando "do"
		do {
			chute = Integer.parseInt(JOptionPane.showInputDialog("Descobra o n�mero:"));
			contador+=1; // contador++; // contador=contador+1;
			//resp = JOptionPane.showInputDialog("Digite <S> para continuar").toUpperCase().charAt(0);
			if (chute>num ) {
				JOptionPane.showInputDialog("Voc� chutou alto!");
			}else if(chute<num) {
				JOptionPane.showInputDialog("Voc� chutou baixo!");
			}
		}while(num != chute);
		
		System.out.println("Parab�ns! Voc� acertou utilizando " + contador + " tentativa(s)!");
	}
}
