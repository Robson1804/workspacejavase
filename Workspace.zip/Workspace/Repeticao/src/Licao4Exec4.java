import javax.swing.JOptionPane;

public class Licao4Exec4 {

	public static void main(String[] args) {
		/*Monte um programa que solicite a idade
		e o nome das pessoas. Ao terminar, 
		o programa dever� exibir a pessoa mais velha, 
		a pessoa mais nova, 
		a quantidade de pessoas maiores de idade 
		e a m�dia entre as idades que foram digitadas.
		*/
		String nomeMaisNovo = "";
		String nomeMaisVelho = "";
		int idadeMaisNovo = 0;
		int idadeMaisVelho = 0;
		int idade = 0;
		int somaIdades = 0;
		int contaMaiorDeIdade = 0;
		int qtdePessoas = 0;
		//int nome = 0;
		char resp = 0;
		do {
			somaIdades = somaIdades + idade;
			qtdePessoas = qtdePessoas + 1;
			idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a sua idade:"));
			String nome = (JOptionPane.showInputDialog("Digite o seu nome"));
			System.out.println("Nome: " + nome + "	" + "Idade: " + idade);
			resp = JOptionPane.showInputDialog("Deseja Continuar? (S/N)").toUpperCase().charAt(0);
			if (idade>17) {
				contaMaiorDeIdade = contaMaiorDeIdade + 1;
			}
			if (qtdePessoas==1) {
				idadeMaisNovo = idade;
				idadeMaisVelho = idade;
				nomeMaisNovo = nome;
				nomeMaisVelho = nome;
			}else {
			if (idade>idadeMaisVelho) {
				nomeMaisVelho = nome;
				idadeMaisVelho = idade;
			}else if (idade<idadeMaisNovo) {
				nomeMaisNovo = nome;
				idadeMaisNovo = idade;
				}
			}
		}while (resp =='S');
		
		System.out.println("Pessoas maiores de idade: " + contaMaiorDeIdade) ;
		System.out.println("A media de idades � : " + (somaIdades / qtdePessoas));
		System.out.println("Nome do mais velho: " + nomeMaisVelho + "	" + "Idade do mais velho: " + idadeMaisVelho);
		System.out.println("Nome do mais novo: " + nomeMaisNovo + "	" + "Idade do mais novo: " + idadeMaisNovo);
	}

}
