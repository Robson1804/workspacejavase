    //window.alert("Sejam todos bem vindos ");   
    var canal="Gama Academy";   
    var curso=" Curso de JavaScript";   
    //alert(canal+curso);  
    var nome=prompt("Entre com o seu nome:");
    //alert("Seja bem vindo "+nome);
    document.write("bem vindo "+ nome); 
    
    function funcao1(){
        alert("Mano você é curioso pacas nééééé");
    } 
    function validar(){    
        var nome = formulario.nome.value;    
        var email= formulario.email.value;    
        var senha= formulario.senha.value;    
        if (nome == ""){
                alert("Por favor preencha o campo nome");        
                formulario.nome.focus();
                return false;    
                }    
                if(email=="" || email.indexOf('@')== -1){ 
                    alert("Preencha o campo email, com um email válido");
                    formulario.email.focus();        
                    return false;   
                }
                if(senha =="" || senha.length <=5) {        
                alert("Preencha o campo senha com o mínimo de 6 caracteres");        
                formulario.senha.focus();        
                return false;    
        }
    }
 
