package br.com.ecommerce.implementacao;

import br.com.ecommerce.modelo.Produto;
import br.com.ecommerce.modelo.Venda;
import br.com.ecommerce.tela.Magica;

public class AplicacaoVenda {

	public static void main(String[] args) {
		Venda obj2 = new Venda();
		Produto obj3 = new Produto(); //Instanciei o "produto" pq ele est� em "Venda"
		
		obj2.setNumero (Magica.i("N�mero"));
		obj2.setOperacao (Magica.s("Opera��o:"));
		obj2.setTotal(Magica.f("Total"));
		obj2.setProduto(obj3); //Colocando o objeto "produto" dentro do objeto "venda"
		obj3.setDescricao(Magica.s("Descri��o"));
		obj3.setId(Magica.i("ID"));
		obj3.setQtde(Magica.i("QTDE"));
		obj3.setTipo(Magica.s("TIPO"));
		obj3.setValorCompra(Magica.f("Valor Compra"));
		obj3.setValorVenda(Magica.f("Valor Venda"));
		
		System.out.println(obj2.getAll());
		//System.out.println(obj3.getAll());
		
		
		
		

	}

}
