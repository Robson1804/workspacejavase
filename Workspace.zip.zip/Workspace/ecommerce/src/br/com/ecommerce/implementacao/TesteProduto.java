package br.com.ecommerce.implementacao;

import javax.swing.JOptionPane;

import br.com.ecommerce.modelo.Produto;

public class TesteProduto {

	public static void main(String[] args) {
		Produto obj1 = new Produto();
		obj1.setAll(
				Integer.parseInt(JOptionPane.showInputDialog("ID")), 
				JOptionPane.showInputDialog("DESCRI�AO"),
				Float.parseFloat(JOptionPane.showInputDialog("Valor Compra")), 
				Float.parseFloat(JOptionPane.showInputDialog("Valor Venda")), 
				Integer.parseInt(JOptionPane.showInputDialog("QTDE")), 
				JOptionPane.showInputDialog("TIPO")
				);
				System.out.println(obj1.getAll());
				System.out.println("Total Venda: " + obj1.getTotalVenda());
				System.out.println("Promo��o: " + obj1.getPromocao());
				System.out.println("Estoque: " + obj1.getEstoque());
				System.out.println("Entra no Estoque: " + obj1.getentrarEstoque());
	}
}