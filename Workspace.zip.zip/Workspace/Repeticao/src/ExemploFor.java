import javax.swing.JOptionPane;

public class ExemploFor {

	public static void main(String[] args) {
		/*
		 * For => � pr�prio para quando n�o existe intera��o do usu�rio
		 * Sintaxe:
		 * 1 - � a vari�vel que vai controlar o la�o
		 * 2 - Condi��o
		 * 3 - Evolu��o da Contagem
		 */
		
		/*for (int cont=0;cont<1000;cont+=1) { // estrutura do for (vari�vel com valor inicial;at� onde vai;qto vai incrementar
			System.out.println(cont);
		}
		*/
		int tabuada = Integer.parseInt(JOptionPane.showInputDialog("Digite a tabuada"));
		for (int cont=1;cont<11;cont+=1) {
			System.out.println(tabuada + " X " + cont + " = " + (tabuada*cont));
		}
	}

}
