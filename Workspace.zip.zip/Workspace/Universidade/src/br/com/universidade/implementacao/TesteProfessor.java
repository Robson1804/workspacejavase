package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.Professor;

public class TesteProfessor {

	public static void main(String[] args) {
		Professor objeto = new Professor();
		objeto.preencherNome(JOptionPane.showInputDialog("Digite o nome do professor"));
		objeto.preencherValorHora(Float.parseFloat(JOptionPane.showInputDialog("Digite o valor hora")));
		objeto.preencherId(Integer.parseInt(JOptionPane.showInputDialog("Digite o ID")));
		objeto.preencherArea(JOptionPane.showInputDialog("Digite a �rea"));
		
		/*
		System.out.println("Nome do professor: " + objeto.retornarNome());
		System.out.println("Valor Hora: " + objeto.retornarValorHora());
		System.out.println("ID: " + objeto.retornarId());
		System.out.println("�rea: " + objeto.retornarArea());
		*/
		
		System.out.println(objeto.retornarTodos());
		
		Professor obj2 = new Professor();
		obj2.preencherTodos(
				JOptionPane.showInputDialog("Nome"), 
				Float.parseFloat(JOptionPane.showInputDialog("Valor Hora")), 
				Integer.parseInt(JOptionPane.showInputDialog("ID")), 
				JOptionPane.showInputDialog("�rea")
				);
		System.out.println(obj2.retornarTodos());
		}

}
