package br.com.universidade.modelo;

public class Professor {
	private String nome;
	private float valorHora;
	private int id;
	private String area;
	
	public void preencherNome (String pNome) {
		nome = pNome.toUpperCase();
	}
	public void preencherValorHora (float pValorHora) {
		valorHora = pValorHora;
	}
	public void preencherId (int pId) {
		id = pId;
	}
	public void preencherArea (String pArea) {
		area = pArea.toUpperCase();
	}
	public String retornarNome() {
		return nome;
	}
	public float retornarValorHora() {
		return valorHora;
	}
	public int retornarId() {
		return id;
	}
	public String retornarArea() {
		return area;
	}
	public String retornarTodos() {
		return nome + "\n" + valorHora + "\n" + id + "\n" + area;
	}
	public void preencherTodos (String pNome, float pValorHora, int pId, String pArea) {
		nome=pNome;
		valorHora=pValorHora;
		id=pId;
		area=pArea;
		
	}
}
