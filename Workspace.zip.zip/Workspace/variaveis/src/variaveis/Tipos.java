package variaveis;

import java.util.Scanner;

public class Tipos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);
		
		System.out.println("Digite seu nome: ");
		String nome = teclado.next();
		System.out.println("Digite a sua idade: ");
		int idade = teclado.nextInt();
		System.out.println("Digite a sua altura: ");
		double altura= teclado.nextDouble();
		System.out.println("Digite o seu peso: ");
		double peso = teclado.nextDouble();
		double IMC = peso  / (altura * altura);
		System.out.println("Nome  : " + nome);
		System.out.println("Idade : " + idade);
		System.out.println("Altura: " + altura);
		System.out.println("Peso  : " + peso);
		System.out.println("IMC   : " + IMC);
		teclado.close();
	}

}
