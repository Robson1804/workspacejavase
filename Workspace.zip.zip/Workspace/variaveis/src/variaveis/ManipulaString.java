package variaveis;

import java.util.Scanner;

public class ManipulaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);
		System.out.println("Digite seu email: ");
		String email = teclado.next();
		System.out.println("Original: " + email);
		System.out.println("Minuscula: " + email.toLowerCase());
		System.out.println("Maiuscula: " + email.toUpperCase());
		System.out.println("Qtde de caracteres: " + email.length());
		System.out.println("Posi��o do @: " + email.indexOf("@"));
		System.out.println("Do 2 ao 4: " + email.substring(1,4));
		System.out.println("A partir do 3: " + email.substring(3));
		System.out.println("Usu�rio: " + email.substring (0, email.indexOf("@")));
		System.out.println("Servidor: " + email.substring (email.indexOf("@") +1));
		System.out.println("Primeiro caracter: " + email.charAt(0));
		System.out.println("Comparando Strings: " + email.equals("robson_p_silva@hotmail.com"));
		System.out.println("Comparando sem caixa: " + email.equalsIgnoreCase("Robson_p_SILVA@HOTmail.com"));
		teclado.close();

	}

}
