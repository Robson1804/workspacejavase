

import javax.swing.JOptionPane;

public class DecisaoEncadeada {

	public static void main(String[] args) {
		String nome = JOptionPane.showInputDialog("Digite o nome do aluno");
		double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a nota 1 do aluno"));
		double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Digite a nota 2 do aluno"));
		int faltas = Integer.parseInt(JOptionPane.showInputDialog("Digite a qtde de faltas"));
		double media = (nota1+nota2) /2;
		if (faltas <=20) {
			if (media>=6) {
				System.out.println("Parab�ns " + nome + ", voc� est� aprovado!");
			}else if (media<6 && media>=3) {
				System.out.println("Tente o exame!");
			}else if (media<3) {
				System.out.println(nome + ", infelizmente voc� foi reprovado.");
			}
		}else {
		System.out.println(nome + ", infelizmente voc� foi reprovado.");
		}		
		/*
		 * O m�todo "showInputDialog" S� importa STRING
		 * Classe Wrapper - S�o as classes que apoiam os tipos primitivos
		 * Ex: a classe para tipo double �: Double.[m�todo]
		 */

	}

}
