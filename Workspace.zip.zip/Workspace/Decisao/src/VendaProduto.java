

import javax.swing.JOptionPane;

public class VendaProduto {

	public static void main(String[] args) {
		String nome = JOptionPane.showInputDialog("Digite o nome do produto").toUpperCase();
		double qtdVenda = Double.parseDouble(JOptionPane.showInputDialog("Digite a Qtde vendida"));
		float preco = Float.parseFloat(JOptionPane.showInputDialog("Digite Pre�o Bruto"));
		String formPag = JOptionPane.showInputDialog("Digite a forma de pagamento (VISTA/CARTAO").toUpperCase();
		float desconto1 = preco * (float) 0.1;
		float desconto2 = preco * (float) 0.05;
		if (formPag.equals("VISTA")) {
			if (qtdVenda >10) {
				preco = preco - desconto1;
			}else 
				preco = preco - desconto2;
		}
		System.out.println("Nome do Produto: " + nome);
		System.out.println("Valor Total: " + preco*qtdVenda);
		//if (formPag.equals("CARTAO")) {
		//System.out.println("Nome do Produto: " + nome);
		//System.out.println("Valor Total: " + preco);
		//}		
		/*
		 * O m�todo "showInputDialog" S� importa STRING
		 * Classe Wrapper - S�o as classes que apoiam os tipos primitivos
		 * Ex: a classe para tipo double �: Double.[m�todo]
		 */

	}

}
