package br.com.banco.implementacao;

import br.com.banco.beans.Conta;

public class TesteConta {

	public static void main(String[] args) {
		Conta obj1 = new Conta();
		obj1.setNumero(123);
		obj1.setTipo("CORRENTE");
		obj1.setAplicacao(0);
		obj1.setLimite(100);
		obj1.setSaldo(10000);
		obj1.setTitular("REGINA");
		
		obj1.sacar(2000);
		System.out.println("O seu saldo real �: " + obj1.getSaldo());
		obj1.depositar(1000);
		System.out.println("O seu saldo real �: " + obj1.getSaldo());
		obj1.aplicarAutomatico();
		System.out.println("O seu saldo real �: " + obj1.getSaldo());
		System.out.println("O total da sua aplica��o �: " + obj1.getAplicacao());
		obj1.aplicarRendimentos(10);
		System.out.println("O total da sua aplica��o com o �ltimo rendimento �: " + obj1.getAplicacao());
	
		System.out.println("O seu saldo + limite �: " + obj1.exbirSaldo());
		

	}

}
