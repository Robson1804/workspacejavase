package br.com.banco.beans;

public class Conta {
	private int numero;
	private String tipo;
	private float saldo;
	private float limite;
	private String titular;
	private float aplicacao;
	
	public Conta() {}
	
	public Conta(int n, String tp, float s, float l, String ti, float a) {
		numero = n;
		tipo = tp;
		saldo = s;
		limite = l;
		titular = ti;
		aplicacao = a;
	}
	
	public void setAll(int numero, String tipo, float saldo, float limite, String titular, float aplicacao) {
		this.numero = numero;
		this.tipo = tipo;
		this.saldo = saldo;
		this.limite = limite;
		this.titular = titular;
		this.aplicacao = aplicacao;
	}
	
	public String getAll() {
		return 
			"N�mero da Conta: " + numero + "\n" + 
			"Tipo           : " + tipo + "\n" + 
			"Sado			: " + saldo + "\n" + 
			"Limte          : " + limite + "\n" + 
			"Nome do Titular: " + titular + "\n" + 
			"Aplica��o      : " + aplicacao;
		
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int PNumero) {
		numero = PNumero;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String PTipo) {
		tipo = PTipo;
	}
	public float getSaldo() {
		return saldo;
	}
	public void setSaldo(float PSaldo) {
		saldo = PSaldo;
	}
	public float getLimite() {
		return limite;
	}
	public void setLimite(float pLimite) {
		limite = pLimite;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String pTitular) {
		titular = pTitular;
	}
	public float getAplicacao() {
		return aplicacao;
	}
	public void setAplicacao(float pAplicacao) {
		aplicacao = pAplicacao;
	}
	public float exbirSaldo() {
		return saldo + limite;
	}
	public void aplicarAutomatico() {
		float valor = saldo * (float) 0.25;
		if (tipo.equals("CORRENTE")) {
			saldo-=valor;
			aplicacao+=valor;
		}
	}
	public void aplicarRendimentos(float porcentagem) {
		aplicacao = aplicacao + aplicacao * (porcentagem/100);
	}
	public void sacar(float valor) {
		saldo-=valor;
	}
	public void depositar(float valor) {
		saldo+=valor;
	}

}
